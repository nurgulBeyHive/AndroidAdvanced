package com.example.nurgul.aalab_2;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView contactListView = (ListView) findViewById(R.id.listView);
        FloatingActionButton floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);



        final ContactAdapter contactAdapter = new ContactAdapter<Contact>(
                this,
                getContactList());
        contactListView.setAdapter(contactAdapter);

        contactListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Contact contact = (Contact)contactAdapter.getItem(position);
                callNewActivity(contact);
            }
        });

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                callNewContact();
            }
        });
    }

    private void callNewActivity(Contact contact){
        String textToShow = "Contact selected: " + contact.getName();
        Toast toast = Toast.makeText(getApplicationContext(), textToShow,  Toast.LENGTH_SHORT);
        toast.show();
    }

    private void callNewContact(){
        startActivity(new Intent(getApplicationContext(), NewContactActivity.class));
    }


    private List<Contact> getContactList() {
        ArrayList<Contact> list = new ArrayList<Contact>();

        Contact contact1 = new Contact();
        contact1.setName("Nurgul");
        contact1.setPhoneNumber("12345678");

        Contact contact2 = new Contact();
        contact2.setName("Laura");
        contact2.setPhoneNumber("12345678");

        Contact contact3 = new Contact();
        contact3.setName("Zhadyra");
        contact3.setPhoneNumber("12345678");

        list.add(contact1);
        list.add(contact2);
        list.add(contact3);

        return list;
    }
}
