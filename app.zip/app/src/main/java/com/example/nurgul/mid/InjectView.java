package com.example.nurgul.mid;

@interface InjectView {
}
